<div class="clear"></div>
<div id="g-nav">
	<div class="g-nav-main g-main">
		<?php echo stripslashes( get_option('cx_nav-ad') ); ?>
	</div>
</div>