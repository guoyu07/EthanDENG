<div id="g-posts">
	<div class="g-posts-main g-main">
		<?php echo stripslashes( get_option('cx_posts-ad') ); ?>
	</div>
</div>