<div id="g-comment">
	<div class="g-comment-main g-main">
		<?php echo stripslashes( get_option('cx_comment-ad') ); ?>
	</div>
</div>