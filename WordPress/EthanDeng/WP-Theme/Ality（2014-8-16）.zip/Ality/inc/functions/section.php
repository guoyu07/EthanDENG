<?php
function section_title_h2($atts, $content = null) {
return '<div class="section"><div class="section_title" title="展开收缩"><h2>'.$content.'<i class="icon-section"></i></h2></div>';
}
add_shortcode("h2", "section_title_h2");

function section_title_h3($atts, $content = null) {
return '<div class="section"><div class="section_title" title="展开收缩"><h3>'.$content.'<i class="icon-section"></i></h3></div>';
}
add_shortcode("h3", "section_title_h3");

function section_content($atts, $content = null) {
return '<div class="section-content">'.$content.'</div></div>';
}
add_shortcode("p", "section_content");
?>