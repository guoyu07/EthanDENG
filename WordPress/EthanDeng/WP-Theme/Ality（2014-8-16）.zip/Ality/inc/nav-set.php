<div id="set-main">
	<div id="nav-search">
		<a class="menu-search" href="#"><i class="icon-search"></i></a>
	</div>
	<div id="nav-login">
		<a href="#login" class="flatbtn" id="login-main" ><i class="icon-login"></i></a>
	</div>
</div>