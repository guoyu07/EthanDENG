<?php
// ��ɫͼ��
add_theme_support( 'post-thumbnails' );
add_image_size( 'thumbnail', 280, 200, true );
?>