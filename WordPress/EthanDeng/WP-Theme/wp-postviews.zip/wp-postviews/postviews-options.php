<?php
/*
+----------------------------------------------------------------+
|																							|
|	WordPress Plugin: WP-PostViews	 								|
|	Copyright (c) 2012 Lester "GaMerZ" Chan									|
|																							|
|	File Written By:																	|
|	- Lester "GaMerZ" Chan															|
|	- http://lesterchan.net															|
|																							|
|	File Information:																	|
|	- Post Views Options Page														|
|	- wp-content/plugins/wp-postviews/postviews-options.php			|
|																							|
+----------------------------------------------------------------+
*/


### Variables Variables Variables
$base_name = plugin_basename('wp-postviews/postviews-options.php');
$base_page = 'admin.php?page='.$base_name;
$id = (isset($_GET['id']) ? intval($_GET['id']) : 0);
$mode = (isset($_GET['mode']) ? trim($_GET['mode']) : '');
$views_settings = array('views_options', 'widget_views_most_viewed', 'widget_views');
$views_postmetas = array('views');


### Form Processing
// Update Options
if(!empty($_POST['Submit'])) {
	$views_options = array();
	$views_options['count'] = intval($_POST['views_count']);
	$views_options['exclude_bots'] = intval($_POST['views_exclude_bots']);
	$views_options['display_home'] = intval($_POST['views_display_home']);
	$views_options['display_single'] = intval($_POST['views_display_single']);
	$views_options['display_page'] = intval($_POST['views_display_page']);
	$views_options['display_archive'] = intval($_POST['views_display_archive']);
	$views_options['display_search'] = intval($_POST['views_display_search']);
	$views_options['display_other'] = intval($_POST['views_display_other']);
	$views_options['template'] =  trim($_POST['views_template_template']);
	$views_options['most_viewed_template'] =  trim($_POST['views_template_most_viewed']);
	$update_views_queries = array();
	$update_views_text = array();
	$update_views_queries[] = update_option('views_options', $views_options);
	$update_views_text[] = __('Post Views 选项', 'wp-postviews');
	$i=0;
	$text = '';
	foreach($update_views_queries as $update_views_query) {
		if($update_views_query) {
			$text .= '<font color="green">'.$update_views_text[$i].' '.__('更新成功', 'wp-postviews').'</font><br />';
		}
		$i++;
	}
	if(empty($text)) {
		$text = '<font color="red">'.__('无新选项被更新', 'wp-postviews').'</font>';
	}
}
// Decide What To Do
if(!empty($_POST['do'])) {
	//  Uninstall WP-PostViews
	switch($_POST['do']) {		
		case __('UNINSTALL WP-PostViews', 'wp-postviews') :
			if(trim($_POST['uninstall_views_yes']) == 'yes') {
				echo '<div id="message" class="updated fade">';
				echo '<p>';
				foreach($views_settings as $setting) {
					$delete_setting = delete_option($setting);
					if($delete_setting) {
						echo '<font color="green">';
						printf(__('Setting Key \'%s\' has been deleted.', 'wp-postviews'), "<strong><em>{$setting}</em></strong>");
						echo '</font><br />';
					} else {
						echo '<font color="red">';
						printf(__('Error deleting Setting Key \'%s\'.', 'wp-postviews'), "<strong><em>{$setting}</em></strong>");
						echo '</font><br />';
					}
				}
				echo '</p>';
				echo '<p>';
				foreach($views_postmetas as $postmeta) {
					$remove_postmeta = $wpdb->query("DELETE FROM $wpdb->postmeta WHERE meta_key = '$postmeta'");
					if($remove_postmeta) {
						echo '<font color="green">';
						printf(__('Post Meta Key \'%s\' has been deleted.', 'wp-postviews'), "<strong><em>{$postmeta}</em></strong>");
						echo '</font><br />';
					} else {
						echo '<font color="red">';
						printf(__('Error deleting Post Meta Key \'%s\'.', 'wp-postviews'), "<strong><em>{$postmeta}</em></strong>");
						echo '</font><br />';
					}
				}
				echo '</p>';
				echo '</div>'; 
				$mode = 'end-UNINSTALL';
			}
			break;
	}
}


### Determines Which Mode It Is
switch($mode) {
		//  Deactivating WP-PostViews
		case 'end-UNINSTALL':
			$deactivate_url = 'plugins.php?action=deactivate&amp;plugin=wp-postviews/wp-postviews.php';
			if(function_exists('wp_nonce_url')) { 
				$deactivate_url = wp_nonce_url($deactivate_url, 'deactivate-plugin_wp-postviews/wp-postviews.php');
			}
			echo '<div class="wrap">';
			echo '<h2>'.__('卸载 WP-PostViews', 'wp-postviews').'</h2>';
			echo '<p><strong>'.sprintf(__('<a href="%s">点击这里</a> 完成卸载WP-PostViews，插件将自动关闭。', 'wp-postviews'), $deactivate_url).'</strong></p>';
			echo '</div>';
			break;
	// Main Page
	default:
		$views_options = get_option('views_options');
?>
<script type="text/javascript">
	/* <![CDATA[*/
	function views_default_templates(template) {
		var default_template;
		switch(template) {
			case 'template':
				default_template = "<?php _e('%VIEW_COUNT% views', 'wp-postviews'); ?>";
				break;
			case 'most_viewed':
				default_template = "<li><a href=\"%POST_URL%\"  title=\"%POST_TITLE%\">%POST_TITLE%</a> - %VIEW_COUNT% <?php _e('views', 'wp-postviews'); ?></li>";
				break;
		}
		jQuery("#views_template_" + template).val(default_template);
	}
	/* ]]> */
</script>
<?php if(!empty($text)) { echo '<!-- Last Action --><div id="message" class="updated fade"><p>'.$text.'</p></div>'; } ?>
<form method="post" action="<?php echo admin_url('admin.php?page='.plugin_basename(__FILE__)); ?>">
<div class="wrap">
	<?php screen_icon(); ?>
	<h2><?php _e('Post Views 选项', 'wp-postviews'); ?></h2>
	<table class="form-table">
		 <tr>
			<td valign="top" width="30%"><strong><?php _e('设置被统计的访问者：', 'wp-postviews'); ?></strong></td>
			<td valign="top">
				<select name="views_count" size="1">
					<option value="0"<?php selected('0', $views_options['count']); ?>><?php _e('所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['count']); ?>><?php _e('只有访客', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['count']); ?>><?php _e('只有注册者', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		 <tr>
			<td valign="top" width="30%"><strong><?php _e('是否排除机器人：', 'wp-postviews'); ?></strong></td>
			<td valign="top">
				<select name="views_exclude_bots" size="1">
					<option value="0"<?php selected('0', $views_options['exclude_bots']); ?>><?php _e('否', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['exclude_bots']); ?>><?php _e('是', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top">
				<strong><?php _e('浏览计数显示模板：', 'wp-postviews'); ?></strong><br /><br />
				<?php _e('Allowed Variables:', 'wp-postviews'); ?><br />
				- %VIEW_COUNT%<br /><br />
				<input type="button" name="RestoreDefault" value="<?php _e('恢复默认模板', 'wp-postviews'); ?>" onclick="views_default_templates('template');" class="button" />
			</td>
			<td valign="top">
				<input type="text" id="views_template_template" name="views_template_template" size="70" value="<?php echo htmlspecialchars(stripslashes($views_options['template'])); ?>" />
			</td>
		</tr>
		<tr>
			<td valign="top">
				<strong><?php _e('浏览最多模板', 'wp-postviews'); ?></strong><br /><br />
				<?php _e('允许的变量：', 'wp-postviews'); ?><br />
				- %VIEW_COUNT%<br />
				- %POST_TITLE%<br />
				- %POST_EXCERPT%<br />
				- %POST_CONTENT%<br />
				- %POST_URL%<br /><br />
				<input type="button" name="RestoreDefault" value="<?php _e('恢复默认模板', 'wp-postviews'); ?>" onclick="views_default_templates('most_viewed');" class="button" />
			</td>
			<td valign="top">
				<textarea cols="80" rows="15"  id="views_template_most_viewed" name="views_template_most_viewed"><?php echo htmlspecialchars(stripslashes($views_options['most_viewed_template'])); ?></textarea>
			</td>
		</tr>
	</table>
	<h3><?php _e('显示设置', 'wp-postviews'); ?></h3>
	<p><?php _e('这个选项让你可以针对指定页面决定是否显示浏览数，默认展示给所有人。注：主题模板中必须用<code>the_views()</code>函数来显示浏览次数。', 'wp-postviews'); ?></p>
	<table class="form-table">
		<tr>
			<td valign="top"><strong><?php _e('首页：', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_home" size="1">
					<option value="0"<?php selected('0', $views_options['display_home']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_home']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_home']); ?>><?php _e('首页不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top"><strong><?php _e('单篇文章：', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_single" size="1">
					<option value="0"<?php selected('0', $views_options['display_single']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_single']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_single']); ?>><?php _e('单篇文章页不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top"><strong><?php _e('页面：', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_page" size="1">
					<option value="0"<?php selected('0', $views_options['display_page']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_page']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_page']); ?>><?php _e('页面不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top"><strong><?php _e('归档页面：', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_archive" size="1">
					<option value="0"<?php selected('0', $views_options['display_archive']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_archive']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_archive']); ?>><?php _e('归档页面不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top"><strong><?php _e('搜索页面', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_search" size="1">
					<option value="0"<?php selected('0', $views_options['display_search']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_search']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_search']); ?>><?php _e('搜索页面不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
		<tr>
			<td valign="top"><strong><?php _e('其它页面：', 'wp-postviews'); ?></strong></td>
			<td>
				<select name="views_display_other" size="1">
					<option value="0"<?php selected('0', $views_options['display_other']); ?>><?php _e('显示给所有人', 'wp-postviews'); ?></option>
					<option value="1"<?php selected('1', $views_options['display_other']); ?>><?php _e('只显示给注册者', 'wp-postviews'); ?></option>
					<option value="2"<?php selected('2', $views_options['display_other']); ?>><?php _e('其它页面不显示', 'wp-postviews'); ?></option>
				</select>
			</td>
		</tr>
	</table>
	<p class="submit">
		<input type="submit" name="Submit" class="button-primary" value="<?php _e('保存更改', 'wp-postviews'); ?>" />
	</p>
</div>
</form> 
<p>&nbsp;</p>

<!-- Uninstall WP-PostViews -->
<form method="post" action="<?php echo admin_url('admin.php?page='.plugin_basename(__FILE__)); ?>">
<div class="wrap"> 
	<h3><?php _e('卸载 WP-PostViews', 'wp-postviews'); ?></h3>
	<p>
		<?php _e('停用 WP-PostViews 不会影响现有浏览统计数据。为了完整的移除，您可以在这里卸载。', 'wp-postviews'); ?>
	</p>
	<p style="color: red">
		<strong><?php _e('警告：', 'wp-postviews'); ?></strong><br />
		<?php _e('一旦卸载,无法恢复。首先你应该备份WordPress插件所有的数据。', 'wp-postviews'); ?>
	</p>
	<p style="color: red">
		<strong><?php _e('以下的 WordPress 选项与文章的自定义栏目将被删除：', 'wp-postviews'); ?></strong><br />
	</p>
	<table class="widefat">
		<thead>
			<tr>
				<th><?php _e('WordPress 选项', 'wp-postviews'); ?></th>
				<th><?php _e('WordPress 自定义栏目', 'wp-postviews'); ?></th>
			</tr>
		</thead>
		<tr>
			<td valign="top">
				<ol>
				<?php
					foreach($views_settings as $settings) {
						echo '<li>'.$settings.'</li>'."\n";
					}
				?>
				</ol>
			</td>
			<td valign="top" class="alternate">
				<ol>
				<?php
					foreach($views_postmetas as $postmeta) {
						echo '<li>'.$postmeta.'</li>'."\n";
					}
				?>
				</ol>
			</td>
		</tr>
	</table>
	<p>&nbsp;</p>
	<p style="text-align: center;">
		<input type="checkbox" name="uninstall_views_yes" value="yes" />&nbsp;<?php _e('是', 'wp-postviews'); ?><br /><br />
		<input type="submit" name="do" value="<?php _e('卸载 WP-PostViews', 'wp-postviews'); ?>" class="button" onclick="return confirm('<?php _e('你要从WordPress卸载WP-PostViews。\n这个操作是不可逆的。\n\n 选择 [取消] 停止, [确定] 卸载。', 'wp-postviews'); ?>')" />
	</p>
</div> 
</form>
<?php
} // End switch($mode)
?>