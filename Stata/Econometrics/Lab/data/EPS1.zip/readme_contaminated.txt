
Description for the earnings data set
--------------------------------------

Source: Census Bureau Current Population Survey 

EARN_contaminated.csv 

Column  Content
-------------------------------------
 1      hourly wage
 2      female (female=1, male=0)
 3      black (black=1, white=0)
 4      education
 5      experience
 6      married (married=1, single=0)
-------------------------------------

Experience = age - education - 6.