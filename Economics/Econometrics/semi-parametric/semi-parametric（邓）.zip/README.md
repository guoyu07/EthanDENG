## 文件列表
+ Question 1: `DGP.R`
+ Question 2 + 3: `semi.R` + `computation.R`
+ Question 4: `DGP2.R` + `semi2.R` 

## 辅助文件
由于计算量过于巨大，所以，这里提供了中间的一些数据

+ 各种方法所计算得到的 beta 在 `beta.xlsx` 中;
+ 通过取样的子样本计算得到的常数 c 存在 `hs.xlsx`，后面两列为 c1、c2;
+ `XY.xlsx` 最后计算得到的数据（半参估计最后用到的数据）。
+ `1000.png` 是样本为 1000 的时候计算得到的最优 h 与 LSCV 最小值。
